
<!DOCTYPE html>
<html lang="en">
<head>
<title>Swift Source Technolgy</title>
<meta name="description" content="We decided to be the vanguard of funds recovery and fight against all types of scams. Our main aim is finding  innovative solutions, ideas and technologies, tactical dispute strategies to help fight  against internet scams and effective recovery of lost funds.	">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
<style type="text/css">
            .navbar-brand {
                display: flex;
                max-width: 50%;
                justify-content: right;
                margin-bottom: -63px;
                
            }
            
          .ftco-navbar-light .navbar-brand {
    color: #235486;
    font-weight: 800;
    font-size: 25px;
}
}
        </style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/animate.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/flaticon.css">
<link rel="stylesheet" href="css/style.css">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;" />
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="mstile-310x310.png" />
<style>
    a{color:#f8f9fa;!important}
</style>
<script async src='/cdn-cgi/challenge-platform/h/b/scripts/invisible.js?ts=1648364400'></script></head>
<body>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/623078a1a34c2456412b2489/1fu6lee98';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>

<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
<div class="container">
<a class="navbar-brand" href="#" style="font-size:18px;">
<img src="w.png" height="30" max-width="50%" class="img-fluid" alt="">
Swift Source
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="fa fa-bars"></span> Menu
</button>
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav m-auto">
<li class="nav-item"><a href="./ " class="nav-link">Home</a></li>
<li class="nav-item"><a href="case" class="nav-link">File A Case </a></li>
<li class="nav-item"><a href="./testimonials" class="nav-link">Testimonials</a></li>
<li class="nav-item active"><a href="about-us" class="nav-link">About </a></li>
</ul>
</div>
</div>
</nav>

<div class="wrap">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="bg-wrap">
<div class="row">
<div class="col-md-6 d-flex align-items-center">
<p class="mb-0 phone pl-md-2">
<a href="/cdn-cgi/l/email-protection#cdbeb8bdbda2bfb98dbebaa4abb9bea2b8bfaea8bee3aea2a0e1a2bda8bfacb9a4a2a3be8dbebaa4abb9bea2b8bfaea8bee3aea2a0" class="mr-2"><span class="fa fa-phone mr-1"></span>File A Case</a>
<a href="/cdn-cgi/l/email-protection#1d726d786f7c697472736e5d6e6a747b696e72686f7e786e337e7270316e686d6d726f695d6e6a747b696e72686f7e786e337e7270"><span class="fa fa-paper-plane mr-1"></span> Contact Operations Officers</a>
</p>
</div>
<div class="col-md-6 d-flex justify-content-md-end">
<div class="social-media">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="hero-wrap">
<div class="container my-5">
<div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
<div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
<h1 class="display-4 fw-bold lh-1">We offer Recoup Services for your lost funds</h1>
<p class="lead">We have noticed the alarming trends online on scams and fraud related activities perpetrated through the internet. We decided to be the vanguard of funds recovery and fight against all types of scams. Our main aim is finding innovative solutions, ideas and technologies, tactical dispute strategies to help fight against internet scams and effective recovery of lost funds.
We have decided to be the defendant to the common internet users, sharing our knowledge and expertise with all internet users who has lost to internet scam. Our main objective is helping every scam victims with free fraud investigation and fund recovery solutions..</p>
<div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
<button type="button" class="btn btn-primary btn-lg px-4 me-md-2 fw-bold"><a href="./contact">Contact</a></button>
</div>
</div>
<div class="col-lg-4 offset-lg-1 p-0 overflow-hidden shadow-lg">
<img class="rounded-lg-3" src="./images/about-us.jpg" alt="" width="720">
</div>
</div>
</div>
</div>
<section class="ftco-section ftco-no-pt bg-light">
<div class="container">
<div class="row d-flex no-gutters">
<div class="col-md-6 d-flex">
<div class="img img-video d-flex align-self-stretch align-items-center justify-content-center justify-content-md-center mb-4 mb-sm-0" style="background-image:url(images/about.jpg);">
</div>
</div>
<div class="col-md-6 pl-md-5 py-md-5">
<div class="heading-section pl-md-4 pt-md-5">
<span class="subheading"> 100 Percent Money Back Guaranteed </span>
<h2 class="mb-4">Get Your Money Back</h2>
</div>
<div class="services-2 w-100 d-flex">
<div class="icon d-flex align-items-center justify-content-center"><span class="flaticon-wealth"></span></div>
<div class="text pl-4">
<h4> The vanguard of funds recovery </h4>
<p> We help retieve moenylost to a scam and fight against all types of scams. Our main aim is finding innovative solutions, ideas and technologies, tactical dispute strategies to help fight against internet scams and effective recovery of lost funds </p>
</div>
</div>
<div class="services-2 w-100 d-flex">
<div class="icon d-flex align-items-center justify-content-center"><span class="flaticon-accountant"></span></div>
<div class="text pl-4">
<h4>Security Advisor & Training</h4>
<p>We provide a security class for all our users in order to educate them on how to identify fradulent activities </p>
</div>
</div>
<div class="services-2 w-100 d-flex">
<div class="icon d-flex align-items-center justify-content-center"><span class="flaticon-teamwork"></span></div>
<div class="text pl-4">
<h4>Free Consultancy</h4>
<p>We provide free Consultation for people who have lost money to an online scam and wish to be refunded all the lost money </p>
</div>
</div>
<div class="services-2 w-100 d-flex">
<div class="icon d-flex align-items-center justify-content-center"><span class="flaticon-accounting"></span></div>
<div class="text pl-4">
<h4>Structured Assestment</h4>
<p>We provide a sturtural assesment of all the details regarding cyber crime and how to prevent falling victim to fradulent individuals </p>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="ftco-section bg-light ftco-no-pt">
<div class="container">
<div class="row">
<div class="col-md-6 col-lg-3 d-flex services align-self-stretch px-4 ftco-animate">
<div class="d-block">
<div class="icon d-flex mr-2">
<span class="flaticon-accounting-1"></span>
</div>
<div class="media-body">
<h3 class="heading">Swift Source Technology</h3>
<p>World class location and tracking system to find and locate funds .</p>
</div>
</div>
</div>
<div class="col-md-6 col-lg-3 d-flex services align-self-stretch px-4 ftco-animate">
<div class="d-block">
<div class="icon d-flex mr-2">
<span class="flaticon-tax"></span>
</div>
<div class="media-body">
<h3 class="heading">Swift Source Technology</h3>
<p>We make sure you do not lose money to online scammers .</p>
</div>
</div>
</div>
<div class="col-md-6 col-lg-3 d-flex services align-self-stretch px-4 ftco-animate">
<div class="d-block">
<div class="icon d-flex mr-2">
<span class="flaticon-loan"></span>
 </div>
<div class="media-body">
<h3 class="heading">Refund Of Money Lost</h3>
<p>We protect you from loss of assets to fradulent parties </p>
</div>
</div>
</div>
<div class="col-md-6 col-lg-3 d-flex services align-self-stretch px-4 ftco-animate">
<div class="d-block">
<div class="icon d-flex mr-2">
<span class="flaticon-budget"></span>
</div>
<div class="media-body">
<h3 class="heading">24 hour Customer Support</h3>
<p>We help you retrieve stolen money and make sure you have all the lost money back safely to you</p>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="ftco-section">
<div class="container">
<div class="row justify-content-center pb-5 mb-3">
<div class="col-md-7 heading-section text-center ftco-animate">
<span class="subheading">We Specialize In Funds/Asset recovery </span>
<h2>Funds Recovery </h2>
</div>
</div>
<div class="row d-flex">
<div class="col-md-4 d-flex ftco-animate">
<div class="blog-entry align-self-stretch">
<a class="block-20 rounded" style="background-image: url('images/image_1.jpg');">
</a>
<div class="text p-4">
<div class="meta mb-2">
<div><a>ROMANCE SCAM</a></div>
<div><a>WE HELP WHEN DEALING WITH MONEY LOST THROUGH PEOPLE WHO TAKE ADVANTAGE OF DATING APPS AND WEBSITES TO SCAM USERS</a></div>
<div><a class="meta-chat"><span class="fa fa-comment"></span>WE MAKE IT OUR PROBLEM TO SEE THAT YOU GET A REFUND </a></div>
</div>
<h3 class="heading"><a a></h3>
</div>
</div>
</div>
<div class="col-md-4 d-flex ftco-animate">
<div class="blog-entry align-self-stretch">
<a class="block-20 rounded" style="background-image: url('images/image_2.jpg');">
</a>
<div class="text p-4">
<div class="meta mb-2">
<div><a>LOCATION SURVEILLIANCE AND TRACKING </a></div>
<div><a>We use satallite imagery to locate & find all perpotrators involved in a Cyber Crime</a></div>
<div><a> We have a security team that specializes in facial recognition and bio metric scans </a></div>
</div>
<h3 class="heading"><a href="#"></a></h3>
</div>
</div>
</div>
<div class="col-md-4 d-flex ftco-animate">
<div class="blog-entry align-self-stretch">
<a class="block-20 rounded" style="background-image: url('images/image_3.jpg');">
</a>
<div class="text p-4">
<div class="meta mb-2">
<div><a>100% GUARANTEE TO RECOVER STOLEN FUNDS</a></div>
<div><a>INLINE WITH THE UNITED NATION POLICY WE TRACK AND MAINTAIN A SYSTEM OF SECURITY COMPANIES TO ACHIEVE A COMMON GOAL OF PROTECTING THE CYBER SPACE </a></div>
<div><a>WE HELP IN REDUCING CYBER CRIME </a></div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<form action="./signup.php" method="post">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">File A CASE </h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<div class="form-group">
<input type="text" class="form-control" placeholder="Your Name" name="name">
</div>
<div class="form-group">
<input type="email" class="form-control" placeholder="Your Email" name="email">
</div>
<div class="form-group">
<input type="number" class="form-control" placeholder="Phone" name="number">
</div>
<div class="form-group">
<input type="text" class="form-control" placeholder="Refrence Number (Optional)" name="ref">
</div>
<div class="form-group">
<textarea name="sc" id="" cols="30" rows="3" class="form-control" placeholder="How were you scammed"></textarea>
</div>
</form>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-danger" onclick="form_submit()">Report Case</button>
<button type="submit" class="btn btn-danger" hidden>Report Case</button>
</div>
</div>
</div>
</div>
</div>
<section class="ftco-section ftco-no-pb ftco-no-pt bg-secondary">
<div class="container py-5">
<div class="row">
<div class="col-md-7 d-flex align-items-center">
<h2 class="mb-3 mb-sm-0" style="color:black; font-size: 22px;">Sign Up for Free Consultation</h2>
</div>
<div class="col-md-5 d-flex align-items-center">
<form action="subscribe.php" class="subscribe-form">
<div class="form-group d-flex">
<input type="text" class="form-control" placeholder="Enter email address">
<input type="submit" value="Subscribe" class="submit px-3">
</div>
</form>
</div>
</div>
</div>
</section>
<footer class="footer">
<div class="container-fluid px-lg-5">
<div class="row">
<div class="col-md-9 py-5">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading"> Swift Source Technology
</h2>
<p>We have decided to be the defendant to the common internet users, sharing our knowledge and expertise with all internet users who has lost to internet scam. Our main objective is helping every scam victims with free fraud investigation and fund recovery solutions.
.</p>
</div>
<div class="col-md-8">
<div class="row justify-content-center">
<div class="col-md-12 col-lg-10">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Services</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./">Home</a></li>
<li><a class="py-1 d-block" href="./about-us">About us</a></li>
<li><a class="py-1 d-block" href="./faqs">Faqs</a></li>
<li><a class="py-1 d-block" href="./testimonials">Testimonials</a></li>
</ul>
</div>
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Need Help?</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./contact">Contact us</a></li>
<li><a class="py-1 d-block" href="./case">File A Case</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-3 py-md-5 py-4 aside-stretch-right pl-lg-5">
<h2 class="footer-heading">Get Started Right Away</h2>
<form action="./signup.php" class="form-consultation" method="post">
<div class="form-group">
<input type="text" class="form-control" placeholder="First Name" name="fname">
</div> <div class="form-group">
<input type="text" class="form-control" placeholder="Last Name" name="lname">
</div>
<div class="form-group">
<input type="email" class="form-control" placeholder="Your Email" name="email">
</div>
<div class="form-group">
<input type="number" class="form-control" placeholder="Phone" name="number">
</div>
<div class="form-group">
<input type="text" class="form-control" placeholder="Reference (Optional)" name="ref">
</div>
<div class="form-group">
<textarea name="sc" id="" cols="30" rows="3" class="form-control" placeholder="How were you scammed"></textarea>
</div>
<div class="form-group">
<button type="submit" class="form-control submit px-3">Report Case</button>
</div>
</form>
</div>
</div>
<p> Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved |Swift Source Technology</p>
</div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script

  <script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
<script type="text/javascript">(function(){window['__CF$cv$params']={r:'6f264c16d8277599',m:'2NIsA1GJ9OnAIJzJT1sv7aNb.xEZjTSdD4dRC5UE5m0-1648364931-0-AVKGjZAYFHEUq6FRqekEOxx1mBAj9ouJLphNSccz+/Ay5qdXUZjS8EVa3DBV+SdPXlvMc6w1p7z3nt64+STBn3kqiuuYKopFh4puiFT8vYPfHvp38IoDSjxvr3v5Na688Q==',s:[0x2b68b71cc5,0x8e73bce778],u:'/cdn-cgi/challenge-platform/h/b'}})();</script></body>
</html>