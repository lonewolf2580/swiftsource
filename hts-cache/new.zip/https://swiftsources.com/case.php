
<!DOCTYPE html>
<html lang="en">
<head>
<title>File A Case- Swift Source</title>
<meta name="description" content="We decided to be the vanguard of funds recovery and fight against all types of scams. Our main aim is finding  innovative solutions, ideas and technologies, tactical dispute strategies to help fight  against internet scams and effective recovery of lost funds.	">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
            .navbar-brand {
                display: flex;
                max-width: 50%;
                justify-content: right;
            }
          
            @media (max-width: 767.98px)
.ftco-navbar-light .navbar-brand {
    margin-bottom: 52px;!important;!
}
            
            .ftco-navbar-light .navbar-brand {
    color: #235486;
    font-weight: 500;
    font-size: 15px;
}
#g-recaptcha-response {
    display: block !important;
    position: absolute;
    margin: -78px 0 0 0 !important;
    width: 302px !important;
    height: 76px !important;
    z-index: -999999;
    opacity: 0;
}
        </style>
<link rel="stylesheet" href="css/animate.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;" />
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="mstile-310x310.png" />
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link rel="stylesheet" href="css/flaticon.css">
<link rel="stylesheet" href="css/style.css">
<script async src='/cdn-cgi/challenge-platform/h/b/scripts/invisible.js?ts=1648364400'></script></head> <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/61dcb5a6f7cf527e84d16e7b/1fp32b5ar';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
        </script>
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
<div class="container">
<a class="navbar-brand" href="#" style="font-size:18px;">
<img src="w.png" height="30" max-width="50%" class="img-fluid" alt="">
Swift Source
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="fa fa-bars"></span> Menu
</button>
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav m-auto">
<li class="nav-item"><a href="./ " class="nav-link">Home</a></li>
<li class="nav-item active"><a href="./case" class="nav-link">File A Case </a></li>
<li class="nav-item"><a href="./testimonials" class="nav-link">Testimonials</a></li>
<li class="nav-item"><a href="./about-us" class="nav-link">About </a></li>
</ul>
</div>
</div>
</nav>

<div class="wrap">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="bg-wrap">
<div class="row">
<div class="col-md-6 d-flex align-items-center">
<p class="mb-0 phone pl-md-2">
<a href="/cdn-cgi/l/email-protection#b2c1c7c2c2ddc0c6f2c1c5dbd4c6c1ddc7c0d1d7c19cd1dddf9eddc2d7c0d3c6dbdddcc1f2c1c5dbd4c6c1ddc7c0d1d7c19cd1dddf" class="mr-2"><span class="fa fa-phone mr-1"></span>File A Case</a>
<a href="/cdn-cgi/l/email-protection#5d322d382f3c293432332e1d2e2a343b292e32282f3e382e733e3230712e282d2d322f291d2e2a343b292e32282f3e382e733e3230"><span class="fa fa-paper-plane mr-1"></span> Contact Operations Officers</a>
</p>
</div>
<div class="col-md-6 d-flex justify-content-md-end">
<div class="social-media">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="contact-wrap">
<div class="container">
<div class="col-md-7 col-lg-8">
<h4 class="mb-3" style="color: rgb(18, 105, 219);">FILE A CASE</h4>
<form class="needs-validation" action="./submited.php" method="POST" name="case" validate>
<div class="row g-3">
<div class="col-sm-6">
<label for="firstName" class="form-label"></label>
<input type="text" class="form-control" id="fname" name="name" placeholder="First Name" value="" required>
<div class="invalid-feedback">
Valid first name is required.
</div>
</div>
<div class="col-sm-6">
<label for="lastName" class="form-label"></label>
<input type="text" name="lname" class="form-control" id="name" placeholder="Last Name" value="" required>
<div class="invalid-feedback">
Valid last name is required.
</div>
</div>
<div class="col-12">
<input type="email" class="form-control" id="email" name="email" placeholder="Email Address" required>
<div class="invalid-feedback">
Please enter a valid email address
</div>
</div>
<div class="col-12">
<div class="input-group has-validation">
<input type="text" name="number" class="form-control" id="number" placeholder="Phone No." value="" required>
</div>
</div>
<div class="col-12">
<div class="input-group has-validation">
<select class="input-group-text">
<option value="" selected="" id="curr" name="curr">Currency</option>
<option value="USD">USD ($)</option>
<option value="GBP">GBP (£)</option>
<option value="EUR">EUR (€)</option>
<option value="AUD">AUD ($)</option>
<option value="ZAR">ZAR (R)</option>
<option value="CAD">CAD ($)</option>
<option value="NZD">NZD ($)</option>
<option value="JPY">JPY (¥)</option>
<option value="RUB">RUB (₽)</option>
<option value="MXN">MXN ($)</option>
</select>
<input type="text" name="aml" class="form-control" id="aml" placeholder="Amount Lost" value="" required>
</div>
</div>
<div class="col-12">
<div>
<input type="text" name="amls" class="form-control" id="amls" placeholder="Amount Lost in US dollars ($USD)" value="" required>
</div>
</div>
<div class="col-12">
<div class="input-group has-validation">
<select class="input-group-text">
<option selected="" id="paymentMethod" name="paymentMethod">Payment method</option>
<option value="Credit Card">Credit/Debit card</option>
<option value="Bank Wire Transfer">Bank wire</option>
<option value="Cryptocurrency">Cryptocurrency</option>
<option value="Other">Other</option>
</select>
</div>
</div>
<span>
<div class="my-3">
<div class="form-check">
<select class="input-group-text">
<option class="form-control" value="" id="lost" name="lost">How did you lose your money</option>
<option value="Phishing Attempt">Phishing Attempt</option>
<option value="Binary Option Scam">Binary Option Scam</option>
<option value="Investment Scam">Investment Scam</option>
<option value="Romance Scam">Romance Scam</option>
<option value="Others">Others</option>
</select>
</div>
</div>
</span>
<div class="col-12">
<label for="Scamrecord" class="form-label"></label>
<textarea input name="scamrecord" class="form-control" id="scamrecord" placeholder="Kindly give a brief load down of how the scam occured?" style="height: 300px;"></textarea>
</div>
</div>
<div>
<div class="input-group has-validation">
<span class="input-group-text">Reference Number</span>
<input type="text" class="form-control" id="ref" placeholder="Optional" name="ref">
<div class="invalid-feedback">
reference number is required.
</div>
</div>
</div>
<div class="g-recaptcha" data-sitekey="6LdBi0AeAAAAADGjaTixyBF9jE5LVOF4DncDqHAr"></div>
<button class="w-100 btn btn-danger btn-lg" class="g-recaptcha" data-sitekey="6LdBi0AeAAAAADGjaTixyBF9jE5LVOF4DncDqHAr" data-callback='onSubmit' data-action='submit' value="Submit" type="submit">FILE CASE</button>
</form>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
   function onSubmit(token) {
     document.getElementById("case").submit();
   }
   window.onload = function() {
    var $recaptcha = document.querySelector('#g-recaptcha-response');

    if($recaptcha) {
        $recaptcha.setAttribute("required", "required");
    }
};
 </script>
<section class="ftco-section ftco-no-pb ftco-no-pt bg-secondary">
<div class="container py-5">
<div class="row">
<div class="col-md-7 d-flex align-items-center">
<h2 class="mb-3 mb-sm-0" style="color:black; font-size: 22px;">Sign Up for Free Consultation</h2>
</div>
<div class="col-md-5 d-flex align-items-center">
<form action="subscribe.php" class="subscribe-form">
<div class="form-group d-flex">
<input type="text" class="form-control" name="sub" placeholder="Enter email address">
<input type="submit" value="Subscribe" class="submit px-3">
</div>
</form>
</div>
</div>
</div>
</section>
<footer class="footer">
<div class="container-fluid px-lg-5">
<div class="row">
<div class="col-md-9 py-5">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading"> Swift Source Technology
</h2>
<p>We have decided to be the defendant to the common internet users, sharing our knowledge and expertise with all internet users who has lost to internet scam. Our main objective is helping every scam victims with free fraud investigation and fund recovery solutions.
.</p>
</div>
<div class="col-md-8">
<div class="row justify-content-center">
<div class="col-md-12 col-lg-10">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Services</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./">Home</a></li>
<li><a class="py-1 d-block" href="./about-us">About us</a></li>
<li><a class="py-1 d-block" href="./faqs">Faqs</a></li>
<li><a class="py-1 d-block" href="./testimonials">Testimonials</a></li>
</ul>
</div>
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Need Help?</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./contact">Contact us</a></li>
<li><a class="py-1 d-block" href="./case">File A Case</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-3 py-md-5 py-4 aside-stretch-right pl-lg-5">
<h2 class="footer-heading">Get Started Right Away</h2>
<form action="./signup.php" class="form-consultation" method="post">
<div class="form-group">
<input type="text" class="form-control" placeholder="First Name" name="fname">
</div> <div class="form-group">
<input type="text" class="form-control" placeholder="Last Name" name="lname">
</div>
<div class="form-group">
<input type="email" class="form-control" placeholder="Your Email" name="email">
</div>
<div class="form-group">
<input type="number" class="form-control" placeholder="Phone" name="number">
</div>
<div class="form-group">
<input type="text" class="form-control" placeholder="Reference (Optional)" name="ref">
</div>
<div class="form-group">
<textarea name="sc" id="" cols="30" rows="3" class="form-control" placeholder="How were you scammed"></textarea>
</div>
<div class="form-group">
<button type="submit" class="form-control submit px-3">Report Case</button>
</div>
</form>
</div>
</div>
<p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |Swift Source Technology</p>
</div>
</footer>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script
  
    <script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="js/main.js"></script>
<script type="text/javascript">(function(){window['__CF$cv$params']={r:'6f264c0afc927599',m:'dKeIEr5KfsUGLbE3RVOZteD00VHBxBJw.yJMySyCO04-1648364930-0-Aa0skPIKmiicpS8ZpNyY1mn+WUjKb829XS9DcD3qOHtetlHFtL/gr+NQcrnigbQHPHz2WFaG9JsUdJonoYqSbaKkX+uUZPTnwUdvU4Rk262PS69C41zb5Z8f1RVwPvjxLw==',s:[0x3a0bf623fe,0xcbf825fb0b],u:'/cdn-cgi/challenge-platform/h/b'}})();</script></body>
</html>