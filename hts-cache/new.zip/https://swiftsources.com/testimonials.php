
<!DOCTYPE html>
<html lang="en">
<head>
<head>
<title>Swift Source Technology</title>
<meta name="description" content="We decided to be the vanguard of funds recovery and fight against all types of scams. Our main aim is finding  innovative solutions, ideas and technologies, tactical dispute strategies to help fight  against internet scams and effective recovery of lost funds.	">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/animate.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style type="text/css">
            .navbar-brand {
                display: flex;
                max-width: 50%;
                justify-content: right;
            }
            
            .ftco-navbar-light .navbar-brand {
    color: #235486;
    font-weight: 800;
    font-size: 15px;
}
        </style>
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/flaticon.css">
<link rel="stylesheet" href="css/style.css">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="favicon-196x196.png" sizes="196x196" />
<link rel="icon" type="image/png" href="favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="favicon-128.png" sizes="128x128" />
<meta name="application-name" content="&nbsp;" />
<meta name="msapplication-TileColor" content="#FFFFFF" />
<meta name="msapplication-TileImage" content="mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="mstile-150x150.png" />
<meta name="msapplication-wide310x150logo" content="mstile-310x150.png" />
<meta name="msapplication-square310x310logo" content="mstile-310x310.png" />
<style>
    a{color:#f8f9fa;!important}
</style>
<script async src='/cdn-cgi/challenge-platform/h/b/scripts/invisible.js?ts=1648364400'></script></head>
<body>


<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/623078a1a34c2456412b2489/1fu6lee98';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>



<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
<div class="container">
<a class="navbar-brand" href="#" style="font-size:18px;">
<img src="w.png" height="30" max-width="50%" class="img-fluid" alt="">
Swift Source
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
<span class="fa fa-bars"></span> Menu
</button>
<div class="collapse navbar-collapse" id="ftco-nav">
<ul class="navbar-nav m-auto">
<li class="nav-item"><a href="./ " class="nav-link">Home</a></li>
<li class="nav-item"><a href="./case" class="nav-link">File A Case </a></li>
<li class="nav-item active"><a href="./testimonials" class="nav-link">Testimonials</a></li>
<li class="nav-item"><a href="./about-us" class="nav-link">About </a></li>
</ul>
</div>
</div>
</nav>
<div class="wrap">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="bg-wrap">
<div class="row">
<div class="col-md-6 d-flex align-items-center">
<p class="mb-0 phone pl-md-2">
<a href="./case" class="mr-2"><span class="fa fa-phone mr-1"></span>File A Case</a>
<a href="/cdn-cgi/l/email-protection#8ae5faeff8ebfee3e5e4f9caf9fde3ecfef9e5fff8e9eff9a4e9e5e7"><span class="fa fa-paper-plane mr-1"></span> Contact Operations Officers</a>
</p>
</div>
<div class="col-md-6 d-flex justify-content-md-end">
<div class="social-media">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<section class="ftco-section testimony-section bg-light">
<div class="overlay"></div>
<div class="container">
<div class="row justify-content-center pb-5 mb-3">
<div class="col-md-7 heading-section heading-section-white text-center ftco-animate">
<span class="subheading">Testimonies</span>
<h2>Happy Clients &amp; Feedbacks</h2>
<pre>What our customers think about us </pre>
</div>
</div>
<div class="row ftco-animate">
<div class="col-md-12">
<div class="carousel-testimony owl-carousel ftco-owl">
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Swift Source really helped me to recoup the funds I lost to a fake gambling website .</p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/ch.jpg);"></div>
<div class="pl-3">
<p class="name">Drake Scott</p>
<span class="position">(Liverpool, England) </span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Swift Source helped save my life from a fraudulent crypto investment scheme.</p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/dre.jpg);"></div>
<div class="pl-3">
<p class="name">Dre Paul</p>
<span class="position">(Toronto, Canada) </span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Fast and reliable, helped me right away to solve my problems</p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/cha.jpg);"></div>
<div class="pl-3">
<p class="name">Francis Bells</p>
<span class="position">(Quebec, Canada) </span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Easily helped me get a refund from a crypto investment scam site. </p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/kate.jpg);"></div>
<div class="pl-3">
<p class="name">Kate Louis</p>
<span class="position">(Kentucky, USA)</span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">The swiftsource team were very helpful and reliable throughout the whole recovery process, even though 100% of the funds weren't recovered , a good amount was recooped due to their expertise, we are forever grateful .</p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/person__.jpg);"></div>
<div class="pl-3">
<p class="name">Mr & Mrs Jeffersons</p>
<span class="position">(Los Angeles ,USA) </span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Swift source customer support was really fast and helped me claim back my money </p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/person_5.jpg);"></div>
<div class="pl-3">
<p class="name">Robert Clark</p>
<span class="position">(Los Angeles ,USA) </span>
</div>
</div>
</div>
</div>
</div>
<div class="item">
<div class="testimony-wrap py-4">
<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-quote-left"></span></div>
<div class="text">
<p class="mb-4">Swift Source Saved our family from finicial doom.</p>
<div class="d-flex align-items-center">
<div class="user-img" style="background-image: url(images/person_.jpg);"></div>
<div class="pl-3">
<p class="name">Mr & Mrs George</p>
<span class="position">(Ohio .U.S.A) </span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<footer class="footer">
<div class="container-fluid px-lg-5">
<div class="row">
<div class="col-md-9 py-5">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading"> Swift Source Technology
</h2>
<p>We have decided to be the defendant to the common internet users, sharing our knowledge and expertise with all internet users who has lost to internet scam. Our main objective is helping every scam victims with free fraud investigation and fund recovery solutions.
.</p>
</div>
<div class="col-md-8">
<div class="row justify-content-center">
<div class="col-md-12 col-lg-10">
<div class="row">
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Services</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./">Home</a></li>
<li><a class="py-1 d-block" href="./about-us">About us</a></li>
<li><a class="py-1 d-block" href="./faqs">Faqs</a></li>
<li><a class="py-1 d-block" href="./testimonials">Testimonials</a></li>
</ul>
</div>
<div class="col-md-4 mb-md-0 mb-4">
<h2 class="footer-heading">Need Help?</h2>
<ul class="list-unstyled">
<li><a class="py-1 d-block" href="./contact">Contact us</a></li>
<li><a class="py-1 d-block" href="./case">File A Case</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-md-3 py-md-5 py-4 aside-stretch-right pl-lg-5">
<h2 class="footer-heading">Get Started Right Away</h2>
<form action="./signup.php" class="form-consultation" method="post">
<div class="form-group">
<input type="text" class="form-control" placeholder="First Name" name="fname">
</div> <div class="form-group">
<input type="text" class="form-control" placeholder="Last Name" name="lname">
</div>
<div class="form-group">
<input type="email" class="form-control" placeholder="Your Email" name="email">
</div>
<div class="form-group">
<input type="number" class="form-control" placeholder="Phone" name="number">
</div>
<div class="form-group">
<input type="text" class="form-control" placeholder="Reference (Optional)" name="ref">
</div>
<div class="form-group">
<textarea name="sc" id="" cols="30" rows="3" class="form-control" placeholder="How were you scammed"></textarea>
</div>
<div class="form-group">
<button type="submit" class="form-control submit px-3">Report Case</button>
</div>
</form>
</div>
</div>
<p> Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved |Swift Source Technology</p>
</div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script
  
    <script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script>	newFunction();
	function newFunction() {
		$(function () {
			$('#basicExampleModal').modal('hide');
		}, 9000);
	}
	

	setTimeout(function() {
		$('#basicExampleModal').modal();
	}, 9000);
</script>
<script src="js/main.js"></script>
<script type="text/javascript">(function(){window['__CF$cv$params']={r:'6f264c140b8f88bf',m:'Gd3vpOh3Yux9wvJ0ytDojKGpAfkZB2m7z6SEdOI11cw-1648364931-0-AS3CZtQV5+u+yyilMv5Dl1PntmpytoABpbNvfumX8W6rF2NqUgAct+AIn6GwW7kR9zBnG0GuvmdgZjSFZnRQlVb1+RTq4CSdKz40x3SQCWaz0vGD5P/i1Mzs5owrK3x1Jk77nzcUOQZDywPDVEA9nZI=',s:[0xf03165ce74,0xc228e84690],u:'/cdn-cgi/challenge-platform/h/b'}})();</script></body>
</html> 